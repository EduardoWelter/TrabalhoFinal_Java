/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package devfreelas;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Empresa extends Usuario{
    @Override
    public void MenuPrincipal()
    {
        Scanner ler = new Scanner(System.in);
        int count = 1;
        do 
        {
            System.out.println("_______MENU_______");
            System.out.println("0.Sair");
            System.out.println("1.Projetos");
            System.out.println("2.Contratantes");
            System.out.println("3.Dev's");
            System. out. println("Digite o codigo desejado:");
            count = ler.nextInt();
            System.out.println("\n\n\n");
            switch (count)
            {
                case 0 -> {
                        }
                case 1 ->                 {
                    this.ProjetosMenu();
                }
                case 2 ->                 {
                    this.ContratantesMenu();
                }
                case 3 ->                 {
                    this.DevsMenu();
                }
            }      
        } while (count != 0);
    }

    private void ProjetosMenu() {
        Scanner ler = new Scanner(System.in);
        int count = 1;
         do
         {
            System.out.println("_______MENU_______");
            System.out.println("0.Voltar");
            System.out.println("1.Listar Projetos");
            System.out.println("2.Meus Projetos");
            System.out.println("3.Criar Projeto");
            System. out. println("Digite o codigo desejado:");
            count = ler.nextInt();
            System.out.println("\n\n\n");
             switch (count)
            {
                case 0 -> {
                        }
                case 1 ->                 {
                    //this.listarprojetos();
                }
                case 2 ->                 {
                    //this.MeusProjetos();
                }
                case 3 ->                 {
                   //this.CriarProjeto();
                }
            }      
        } while (count != 0);
            
    }

    private void ContratantesMenu() {
        Scanner ler = new Scanner(System.in);
        int count = 1;
         do
         {
            System.out.println("_______MENU_______");
            System.out.println("0.Voltar");
            System.out.println("1.Listar Empresas");
            System.out.println("2.Meu Perfil");
            System.out.println("3.Alterar Perfil");
            System. out. println("Digite o codigo desejado:");
            count = ler.nextInt();
            System.out.println("\n\n\n");
             switch (count)
            {
                case 0 -> {
                        }
                case 1 ->                 {
                    //this.ListarEmpresas();
                }
                case 2 ->                 {
                    //this.MeuPerfil();
                }
                case 3 ->                 {
                   //this.AlterarPerfil();
                }
            }      
        } while (count != 0);
    }

    private void DevsMenu() {
        Scanner ler = new Scanner(System.in);
        int count = 1;
         do
         {
            System.out.println("_______MENU_______");
            System.out.println("0.Voltar");
            System.out.println("1.Listar Dev's");
            System.out.println("2.Dev's Contratados");
            System. out. println("Digite o codigo desejado:");
            count = ler.nextInt();
            System.out.println("\n\n\n");
             switch (count)
            {
                case 0 -> {
                        }
                case 1 ->                 {
                    //this.ListarDevs();
                }
                case 2 ->                 {
                    //this.DevsContratados();
                }
            }      
        } while (count != 0);
    }
}
