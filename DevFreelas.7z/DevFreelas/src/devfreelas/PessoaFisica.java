/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package devfreelas;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class PessoaFisica extends Usuario{
    
    public PessoaFisica(String nome, String user, String senha, int tipo, String documento) {
        this.setUser(user);
        this.setSenha(senha);
        this.tipo = tipo;
        this.setDocumento(documento);
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public PessoaFisica(String nome) {
    }

    PessoaFisica() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
        public void MenuPrincipal()
    {
        int count = 1;
        Scanner ler = new Scanner(System.in);
        do 
        {
            System.out.println("_______MENU_______");
            System.out.println("0.Sair");
            System.out.println("1.Projetos");
            System.out.println("2.Contratantes");
            System.out.println("3.Dev's");
            System. out. println("Digite o codigo desejado:");
            count = ler.nextInt();
            System.out.println("\n\n\n");
            switch (count)
            {
                case 1:
                {
                    this.ProjetosMenu();
                    break;
                }
                case 2:
                {
                    this.ContratantesMenu();
                    break;
                }
                case 3:
                {
                    this.DevsMenu();
                    break;
                }
            }      
        } while (count != 0);
    }

    private void ProjetosMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void ContratantesMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void DevsMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
