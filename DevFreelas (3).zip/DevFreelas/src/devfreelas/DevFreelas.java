/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package devfreelas;
import java.io.IOException;
import java.util.Scanner;

public class DevFreelas 
{
    public static void main(String[] args) throws IOException 
    {
        int count = 0;
        Scanner ler = new Scanner(System.in);
        
        UsuarioDAO udao = new UsuarioDAO();
        ServicoLogin dadosLogin = new ServicoLogin();
        
        Usuario p1 = new Usuario();
        
        do
        {
            System.out.println("Ja possui uma conta conosco?");  
            System.out.println("1.Sim - 2.Nao");
            count = ler.nextInt();
            if (count == 1)
            {
                //ServicoLogin.logar(); nao consegui chamar a função
            }
            else if(count == 2)
            {
                System.out.println("Que tipo de Usuario deseja criar?");
                System.out.println("0.Freelancer - 1.Empresa(contratar)");
                p1.tipo = ler.nextInt();
                System.out.println("Digite seu nome de usuario:");
                p1.user = ler.nextLine();
                System.out.println("Digite a sua senha:");
                p1.setSenha(ler.nextLine());
                System.out.println("Digite seu CNPJ-CPF:");
                p1.setDocumento(ler.nextLine());
                if (p1.tipo == 1)
                {
                    p1 = new Empresa();
                }
                else
                {
                    p1 = new PessoaFisica();
                }
                udao.inserir(p1);
            }
            p1.MenuPrincipal();
        }
         while(count != 0);
        
    }
    
}
