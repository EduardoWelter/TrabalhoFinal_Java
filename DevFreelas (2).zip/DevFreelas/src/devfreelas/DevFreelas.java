/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package devfreelas;
import java.io.IOException;
import java.util.Scanner;

public class DevFreelas 
{
    public static void main(String[] args) throws IOException 
    {
        int count = 0;
        Scanner ler = new Scanner(System.in);
        
        UsuarioDAO udao = new UsuarioDAO();
        ServicoLogin dadosLogin = new ServicoLogin();
        
        PessoaFisica p1;
        p1 = new PessoaFisica("Maria", "choco","00000000000", "Maria do Bairro", false);
        udao.inserir(p1);
        
        do 
        {
            p1.MenuPrincipal();
            count = 0;
        } while (count != 0);
    }
    
}
