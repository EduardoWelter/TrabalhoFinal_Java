/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package devfreelas;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class PessoaFisica extends Usuario{
    String cpf;
    String nome;

    public PessoaFisica(String cpf, String nome, String user, String senha, boolean tipo) {
        super(user, senha,tipo);
        this.cpf = cpf;
        this.nome = nome;
    }

    public PessoaFisica(String cpf, String nome) {
        this.cpf = cpf;
        this.nome = nome;
    }
        public void MenuPrincipal()
    {
                int count = 0;
        Scanner ler = new Scanner(System.in);
        do 
        {
            System.out.println("_______MENU_______");
            System.out.println("0.Sair");
            System.out.println("1.Projetos");
            System.out.println("2.Contratantes");
            System.out.println("3.Dev's");
            System. out. println("Digite o codigo desejado:");
            count = ler.nextInt();
            System.out.println("\n\n\n");
            switch (count)
            {
                case 1:
                {
                    this.ProjetosMenu();
                    break;
                }
                case 2:
                {
                    this.ContratantesMenu();
                    break;
                }
                case 3:
                {
                    this.DevsMenu();
                    break;
                }
            }      
        } while (count != 0);
    }

    private void ProjetosMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void ContratantesMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void DevsMenu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
