/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package devfreelas;
import java.io.IOException;
import java.util.Scanner;

public class DevFreelas 
{
    public static void main(String[] args) throws IOException 
    {
        int count = 0;
        Scanner ler = new Scanner(System.in);
        
        UsuarioDAO udao = new UsuarioDAO();
        ServicoLogin dadosLogin = new ServicoLogin();
        
        PessoaFisica pf1 = new PessoaFisica("00000000000", "Maria do Bairro","Maria", "choco");
        udao.inserir(pf1);
        do 
        {
            pf1.MenuPrincipal();
            count = 0;
        } while (count != 0);
    }
    
}
